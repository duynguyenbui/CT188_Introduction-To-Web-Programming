function dangky(){
    var dky = document.forms['regfr'];
    var user = dky.user;
    var hoten = dky.hoten;
    var ns = dky.ns;

    //mail
    var mail = dky.mail;
    var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    
    //mật khẩu
    var pw = dky.pw;
    var strongRegex = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})");
    
    //nhập lại mật khẩu
    var pre_pw = dky.pre_pw;
    
    //kiểm tra họ tên không rỗng
    if(hoten.value.length == 0){
            alert("Hãy điền họ tên!");
            hoten.focus();
            return false;
    }

    //kiểm tra tên đăng nhập không rỗng
    if(user.value.length == 0){
            alert("Hãy điền họ tên!");
            user.focus();
            return false;
    }

    //ngày sinh: đủ 18 tuổi trở lên
    var today = new Date();
    var t1 = new Date(ns.value);
    var ns1 = today.getFullYear() - t1.getFullYear();
        
    if(ns1 <= 18 || isNaN(ns1) ){
        alert("Ngày sinh không được rỗng và đủ 18 tuổi trở lên !");
        ns.focus();
        return false;
    }

    //mail đúng
    if(!filter.test(mail.value)){
        alert("Hãy nhập đúng định dạng Mail !");
        mail.focus();
        return false;
    }

    //kiểm tra mật khẩu
    if(strongRegex.test(pw.value) == false){
        alert("Mật khẩu có ký tự in 'HOA', thường, ký tự đặc biệt và số !");
        pw.focus();
        return false;
    }

    //nhập lại mật khẩu
    if(pw.value != pre_pw.value){
        alert("Nhập lại mật khẩu không trùng khớp");
        pre_pw.focus();
        return false;
        
    }
    
    alert("Đăng ký thành công!");
    return true;
}

var account ='{"nguoidung":[{"username":"admin","password":"Abc@123"}]}';
var obj = JSON.parse(account);
function dangnhap(){
    var dnhap =document.forms['login'];
    var user = dnhap.user;
    var pw = dnhap.pw;

    if((user.value == obj.nguoidung[0].username) && (pw.value == obj.nguoidung[0].password))
        alert('Thành công !')
    else
        alert('Sai tài khoản hoặc mật khẩu !');
}