var x=true;
        function myfunction(){
            if(x){
                document.getElementById('psw').type ="text";
                x = false;
            }
            else{
                document.getElementById('psw').type ="password";
                x= true;
            }
            
        } 

        var text = '{"account":[{"fullname":"thành","username":"thanhsilva", "password":"abc@1234"},{"fullname":"thành","username":"admin", "password":"abc@1234"}]}';

        const accountList = JSON.parse(text);

        function logInValidation(){
            var frm = document.forms['loginForm'];
            var username = frm.user.value;
            var password = frm.psw.value;
            var check = document.getElementById('saveInfo');

            accountList.account.forEach(function(e){
                    if(username == e.username && password == e.password){
                        if(check.checked === true) 
                            window.localStorage.setItem(username, e.fullname);
                        window.location.href = "index.html";
                        alert('Đăng nhập thành công!');
                        e.stopPropagation();
                        return true;
                }
            });

            alert('Tên đăng nhập hoặc mật khẩu không đúng!');
            return false;
        }
