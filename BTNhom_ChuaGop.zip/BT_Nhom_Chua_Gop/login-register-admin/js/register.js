
function frmValidate(){
    var frm = document.forms('regfr');
    var nsinh = frm.ns;
    var name =frm.hoten;
    // chap nhan
    var t = frm.check;
    if(t ==true){
        
    }
    else{
        alert('Vui lòng đồng ý');
        return;
    }
    //mat khau
    var mk = frm.mk;
    var strongRegex = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})");
    //kiem tra mk
    if(strongRegex.test(mk.value) == false){
        alert("Mk có ký tự in HOA, thường, ký tự đặc biệt và số!");
        mk.focus();
        return false;
    }
    //kt ho ten khong rong
    if(hoten.value.length == 0){
        alert("Hãy điền họ tên!");
        hoten.focus();
        return false;
    }
}